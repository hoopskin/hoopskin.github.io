See https://data.fivethirtyeight.com/ for a list of the data and code we've published.

Unless otherwise noted, our data sets are available under the [Creative Commons Attribution 4.0 International License](https://creativecommons.org/licenses/by/4.0/), and the code is available under the [MIT License](https://opensource.org/licenses/MIT). If you find this information useful, please [let us know](mailto:data@fivethirtyeight.com).
