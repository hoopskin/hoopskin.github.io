# Comma Survey

This folder contains the data behind the story [Elitist, Superfluous, Or Popular? We Polled Americans on the Oxford Comma](https://fivethirtyeight.com/features/elitist-superfluous-or-popular-we-polled-americans-on-the-oxford-comma/).