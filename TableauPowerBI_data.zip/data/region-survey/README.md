# Region Survey

This folder contains data behind the stories:

* [Which States Are in the South?](http://fivethirtyeight.com/datalab/which-states-are-in-the-south/)
* [Which States Are in the Midwest?](http://fivethirtyeight.com/datalab/what-states-are-in-the-midwest/)
* [We’ve Published Our Data on the South And Midwest](http://fivethirtyeight.com/datalab/weve-published-our-data-on-the-south-and-midwest/)

`SOUTH.csv` and `MIDWEST.csv` contain individual responses from surveys about regional identification conducted for FiveThirtyEight by SurveyMonkey.
